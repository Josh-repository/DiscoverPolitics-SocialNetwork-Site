describe('less.js strict units tests', function() {
    testLessEqualsInDocument();
});
